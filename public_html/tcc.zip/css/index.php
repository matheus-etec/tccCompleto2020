<style>
    @import url("https://fonts.googleapis.com/css2?family=Roboto&display=swap");
    * {
        font-family: Roboto;
    }

    body {
    padding: 0;
    margin: 0;
    }

    .homepagebg {
        box-shadow: 1px 1px 3000px 250px rgba(0, 0, 0, 0.5) inset;
        -webkit-box-shadow: 50px 10px 999999999px 100px rgba(255, 255, 255, 0.377) inset;    
        background-image: url(../css/backgrounds/background6.png);
        background-attachment: fixed;
        background-size: cover;
        background-repeat: no-repeat;
        user-select: none;
        height: auto;
        padding-bottom: 150px;
        text-align: center;
    }

    #imagem-corpo {
        box-shadow: 0 0 3000px rgb(0, 0, 0) inset;
    
        background-image: url(../css/backgrounds/scroll.jpg);
        background-attachment: cover;
        background-position: fixed;
        user-select: none;
        padding-top: 100px;
        padding-bottom: 20px;
        text-align: center;
        height: auto;
    }

    #imagem-corpo .imagem-corpo-titulo {
        text-align: center;
        margin-left: 55px;
        padding-top: 100px;
        padding-bottom: 150px;
        background-repeat: no-repeat;
        background-image: url(../css/backgrounds/background4.png);
    }

    .botoes-nav {
    display: flex;
    position: absolute;
    }

    .homepagebg button {
        color: rgb(255, 255, 255);
        background-color: #A12830;
        opacity: 100%;
        box-shadow: 1px 2px 10px 1px;
        font-size: 24px; 
        font-weight: bolder;
        letter-spacing: 2px;
        border-radius: 7.5px;
        margin: 10px;
        height: 50px;
        width: 350px;
    }

    #imagem-corpo button {
        background-color: #A12830;
        color: rgb(255, 255, 255);
        opacity: 90%;
        box-shadow: 2px 2px 10px 2px;
        font-weight: bolder;
        font-size: 24px;
        border-radius: 7.5px;
        margin: 10px;
        height: 50px;
        width: 350px;
        letter-spacing: 2px;
    }

    .botoes-nav a {
        color: rgb(255, 255, 255);
        background-color: #A12830;
        opacity: 90%;
        box-shadow: 1px 2px 10px 1px;
        font-size: 18.5px;
        border-radius: 7.5px;
        margin: 10px;
        height: 45px;
        width: 200px;
    }

    #imagem-corpo button:hover,
    .homepagebg button:hover,
    .botoes-nav a:hover {
        color: rgb(255, 255, 255);
        border-radius: 10px;
        opacity: 80%;
    }

    .homepagebg strong {
        letter-spacing: 2px;
        padding-bottom: 100px;
        text-align: center;
        font-size: 45px;
        color: #fff;
    }

    #imagem-corpo h1, h2 {
        padding-top: 40px;
        font-weight: bolder;
        color: #000;
        padding-bottom: 5px;
        font-size: 50px;
        letter-spacing: 1px;
    }

    #imagem-corpo p {
        letter-spacing: 1px;
        font-weight: bolder;
        color: #000;
        font-size: 24px;
        text-justify: initial;
        padding: 40px 90px;
    }
    
    h6 {
        text-align: right;
        padding-top: 30px;
        color: #000;
        font-size: 15px;
        padding-right: 15px;
    }

    .homepagebg button {
        margin-top: 200px;
    }
</style>