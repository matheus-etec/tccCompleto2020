<!DOCTYPE html>
<html lang="pt-br">

  <head>
    <meta http-equiv="content-type" charset="UTF-8"/>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title>Taverna Online</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
     integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  </head>

  <body>

  <?php
    require("conexao.php");
    require("./css/index.php");
  ?>
   
    <div class="homepagebg">
      <div class="botoes-nav container-fluid justify-content-end my-5">
        <form class="d-flex">
          <a class="nav-link active btn btn-outline" href="inicio.php">Entrar</a>
          <a class="nav-link active btn btn-outline" href="cadastro.php">Cadastrar</a>
        </form>
      </div>
      <div class="logo">
        <nav class="nav">
          <a class="navbar-brand" href="index.php">
            <img src="./img/logo.png" alt="logo" width="260" height="175">
          </a>
        </nav>
      </div>
      <p><strong>Jogue RPG de mesa com seus amigos!</strong></p>

      <form method="GET" action="inicio.php">
        <button type="submit" class="btn btn-outline">Crie sua mesa!</button>
      </form>
    </div>

    <div id="imagem-corpo">
      <div class="imagem-corpo-titulo">
        <h1>Seja bem vindo!</h1>
        <h2>A sua nova plataforma role-playing games</h2>
          <section class="corpo">
            <p>O Taverna Online é um combinador de sessões online, que tem como principal
              função unir jogadores que precisam de um grupo e mestres de sessão Role-playing
                game (RPG) online ou presencial.
              O objetivo é fazer com que os jogadores se sintam confortáveis e próximos, mesmo
              estando distantes uns dos outros, que eles consigam jogar com pessoas de localidade
                próxima ou distante sem problemas, pensamos em oferecer não só proximidade, mas
                também interação e particularidade já que será dedicado somente ao RPG.</p>
          </section>

          <section class="button-corpo">

            <form method="GET" action="cadastro.php">
              <button type="submit" class="btn btn-outline">Crie sua conta</button>
            </form>

          </section>
      </div>
          <section class="rodape">
            <footer>
                <div class="col-md-12 text-center mt-5">
                    <h5>@Taverna Online todos os direitos reservados</h5>
                </div>
            </footer>
          </section>
    </div>

    <!-- jQuery and JS bundle w/ Popper.js -->
    <script src="./js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" 
    integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" 
    integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
  </body>
</html>