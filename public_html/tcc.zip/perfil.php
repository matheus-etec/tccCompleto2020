<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <link rel="stylesheet" href="css/style.css">

</head>
<body>

    <?php 
        require("conexao.php");
    ?>

    
    <header class="sticky-top">
        <nav class="navbar navbar-expand-lg navbar-light bg-danger ">
            <div style="height: 100px;">
                <div class="mh-100px" style="width: 100px; height: 100px;">
                    <img src="img/logo.png" class="img-fluid mt-2 " alt="Imagem responsiva">
                </div>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse " id="conteudoNavbarSuportado">
                <ul class="navbar-nav mr-auto ">
                
                <li class="nav-item align-middle my-auto  li-itens ">
                    <a class="nav-link my-auto" href="inicio.php"> <h5 class="font-weight-bold text-white my-auto">Início</h5></a>
                </li>
                
                <li class="nav-item align-middle my-auto li-itens">
                    <a class="nav-link my-auto" href="#"> <h6 class="text-white my-auto">Pesquisar</h6></a>
                </li>

                <li class="nav-item align-middle my-auto li-itens">
                    <a class="nav-link my-auto" href="#"> <h6 class="text-white my-auto">Criar Mesas</h6></a>
                </li>

                </ul>
            </div>
        </nav>
    </header>

    <section class="bg-light text-center py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <h1>Seus Dados</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Cód.</th>
                                <th scope="col">Nome</th>
                                <th scope="col">Email</th>
                                <th scope="col">Senha</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php 
                            
                            $qry = "SELECT * FROM USUARIO";

                                if ($result = mysqli_query($conexao, $qry)) {

                                    while ($row = mysqli_fetch_row($result)) {

                                        echo '                        
                                        <tr>
                                            <th scope="row">'.$row[0].'</th>
                                            <td>'.$row[1].'</td>
                                            <td>'.$row[2].'</td>
                                            <td>'.$row[3].'</td>
                                            <td><a href="edicao-usuarios.php?id='.$row[0].'" class="btn btn-sm btn-info"> EDITAR </a> </td>
                                        </tr>
                                        ';

                                    }
                                    
                                    mysqli_free_result($result);
                                }   

                            mysqli_close($conexao);

                            ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </section>
    

    <section class="align-bottom" id="contato">
        <div class="container">
            <div class="row justify-content-center" >
                <div class="col-md-12 text-center">
                    <a href="#" target="_blank"><img src="img/facebook.svg" class="rounded-circle"></a>
                    <a href="#" target="_blank"><img src="img/whatsapp-contato.svg" class="rounded-circle mr-5 ml-5"></a>
                    <a href="#" target="_blank"><img src="img/instagram.svg" class="rounded-circle "></a>
                </div>

                <div class="col-md-12 text-center mt-5">
                    <h3>@Taverna Online todos os direitos reservados</h3>
                </div>
            </div>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

</body>
</html>