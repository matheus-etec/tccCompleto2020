<!DOCTYPE html>
<html lang="pt-br">
<head>

  <meta charset="UTF-8">
  <title>Teste Login TCC</title>
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

  <?php
    require("conexao.php");
    require("./css/stylesForm.css");
  ?>

  <div class="homepagebg align" style="height: 100vh !important;">
    <div class="grid align__item">

      <div class="register">
          
          <img class="logo" src="./img/logo.png">
        
        <h2 class="tituloForms">Login</h2>

        <form action="" method="post" class="form">

          <div class="form__field">
            <input class="inputForm" type="email" placeholder="Email">
          </div>

          <div class="form__field">
            <input class="inputForm" type="password" placeholder="Senha">
          </div>

          <div class="form__field">
            <input class="inputForm" type="submit" value="Entrar">
          </div>

        </form>

        <p>Ainda não tem uma conta? <a class="linkCadastrar" href="cadastro.php">Cadastre-se</a></p>

      </div>

    </div>

</div>

</body>
</html>
