<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Dados</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

</head>

<body>
    
    <?php
     require("conexao.php");
    ?>

    <section class="bg-light text-center py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <h1>Editar Dados</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <h3>Atualizar Informações</h3>

                    <?php 
                        $idConsulta = $_GET['ID_Usuario'];
                        
                        $qry = 'SELECT * FROM USUARIO WHERE ID_Usuario = '.$idConsulta;

                        $ID_Usuario;
                        $NM_Usuario;
                        $Email_Usuario;
                        $Senha_Usuario;

                        if ($result = mysqli_query($conexao, $qry)) {

                            while ($row = mysqli_fetch_row($result)) {
                                $ID_Usuario    = $row[0];
                                $NM_Usuario  = $row[1];
                                $Email_Usuario    = $row[2];
                                $Senha_Usuario = $row[3];
                            }
                            
                            mysqli_free_result($result);
                        }   

                        mysqli_close($conexao);

                    
                        echo '
                        <form action="atualizardados.php" method="POST">
                            <div class="form-group">
                                <label for="id">Código</label>
                                <input type="text" value="'.$ID_Usuario.'" class="form-control" id="id" name="id" readonly>
                            </div>

                            <div class="form-group">
                                <label for="nome">Nome</label>
                                <input type="text" value="'.$NM_Usuario.'" class="form-control" id="nome" name="nome">
                            </div>

                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="text" value="'.$Email_Usuario.'" class="form-control" id="email" name="email">
                            </div>

                            <div class="form-group">
                                <label for="senha">Senha</label>
                                <input type="text" value="'.$Senha_Usuario.'" class="form-control" id="senha" name="senha">
                            </div>

                            <button type="submit" class="btn btn-success">Atualizar Dados</button>
                        </form>
                        ';
                    ?>
                </div>
            </div>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s"crossorigin="anonymous"></script>

</body>

</html>